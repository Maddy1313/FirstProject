//
//  ViewController.swift
//  Second test app for xib
//
//  Created by Maddy on 10/15/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


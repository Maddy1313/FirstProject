//
//  signUpView.swift
//  Second test app for xib
//
//  Created by Maddy on 10/15/20.
//

import UIKit

class signUpView: UIView {

    @IBAction func Signup(_ sender: Any) {
       didMoveToWindow()
    }
    
}

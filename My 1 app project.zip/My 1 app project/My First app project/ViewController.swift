//
//  ViewController.swift
//  My First app project
//
//  Created by Maddy on 10/12/20.
//
import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPWD: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func logintapped(_ sender: Any) {
        let email: String = (self.txtEmail.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        let password: String = (self.txtPWD.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        if (password != "" &&  email != ""){
            if (Utility.isValidEmail(str: email) && ((self.validatePassword(strPWD: password)) != nil)){
    //            print("Login successfully")
            }
            else if !Utility.isValidEmail(str: email){
                print("Wrong Email")
            }
        }
        else{
            print("Error")
        }
    }
    
    func validatePassword(strPWD: String?) -> String?{
           
           let length: Int = strPWD?.count ?? 0
           if length >= 7 {
               print ("Password is valid")
           }
           else {
               print("Password is invalid")
               let msg = "Password must be 7 character"
               print(msg)
           }
           return ""
       }
    
}


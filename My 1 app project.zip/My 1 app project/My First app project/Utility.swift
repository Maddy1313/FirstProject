//
//  Utility.swift
//  My First app project
//
//  Created by Maddy on 10/12/20.
//

import UIKit

class Utility: NSObject {
    static func isValidEmail(str: String) -> Bool{
            let emailEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let testEmail = NSPredicate(format: "SELF MATCHES %@", emailEx)
            
            return testEmail.evaluate(with: str)
        
        }
       
}

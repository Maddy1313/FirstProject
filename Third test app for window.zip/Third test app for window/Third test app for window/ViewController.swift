//
//  ViewController.swift
//  Third test app for window
//
//  Created by Maddy on 10/18/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


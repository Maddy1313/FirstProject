//
//  customViewController.swift
//  Third test app for window
//
//  Created by Maddy on 10/19/20.
//

import UIKit

class customViewController: UIViewController {

    override func loadView() {
        super.loadView()
        
        view.backgroundColor = .systemRed
        
        let container = UIView(frame: CGRect(x: 50, y: 50, width: 150, height: 150))
        container.backgroundColor = .white
        view.addSubview(container)
        
        container.translatesAutoresizingMaskIntoConstraints = false
        
        container.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        container.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        container.widthAnchor.constraint(equalToConstant: 100).isActive = true
        container.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        
        let button = UIButton (frame: CGRect(x: 100, y: 100, width: 20, height: 10))
        button.backgroundColor = .gray
        view.addSubview(button)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        
        button.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        button.widthAnchor.constraint(equalToConstant: 120).isActive = true
        button.heightAnchor.constraint(equalToConstant: 120).isActive = true
        
        
        let textField = UITextField(frame: CGRect(x: 70, y:70, width: 120, height: 120))
        textField.backgroundColor = .gray
        view.addSubview(textField)
        textField.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        textField.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        textField.widthAnchor.constraint(equalToConstant: 110).isActive = true
        textField.heightAnchor.constraint(equalToConstant: 110).isActive = true
        
    }
    
        
        override func viewDidLoad() {
            super.viewDidLoad()
        }
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */



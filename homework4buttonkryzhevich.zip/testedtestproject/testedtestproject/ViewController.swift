//
//  ViewController.swift
//  testedtestproject
//
//  Created by Maddy on 10/21/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func goToNext(_ sender: Any) {
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let NewViewContoller = storyboard.instantiateViewController(withIdentifier: "vc") as! NewViewController
        self.present(NewViewContoller, animated: true, completion: nil)
    }
    
    
    @IBAction func goVCVC(_ sender: Any) {
        performSegue(withIdentifier: "goToVC", sender: nil)
    }
    
}


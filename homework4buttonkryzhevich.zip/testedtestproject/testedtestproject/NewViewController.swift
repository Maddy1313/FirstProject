//
//  NewViewController.swift
//  testedtestproject
//
//  Created by Maddy on 10/22/20.
//

import UIKit

class NewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    

}
